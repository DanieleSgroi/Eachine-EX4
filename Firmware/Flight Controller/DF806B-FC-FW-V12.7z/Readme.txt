FLIGHT-DF806B-v1.2-2019.10.29 (36ea946c)

Fight Controller Firmware extracted from a green PCB DF806_Main_Board-V2.4 dated 2019.09.25.

This firmware deos not need an Optical Flow sensor connectd (on spare serial port), and replaces 
previous v0.2 version (which requires unkonwn type of OF sensor).

Put the micro in DFU mode and upload with DFuse demo.